package dev.startsoftware.gridcoloredcellsboard

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var bt_board8=findViewById<Button>(R.id.bt_board8)
        bt_board8.setOnClickListener {
            buildGrid(8)
        }
    }
    private fun buildGrid(number: Int){
        var lt_board=findViewById<LinearLayout>(R.id.lt_board)
        lt_board.removeAllViews()
        for (row in 0..number-1) {
            var lt_row = layoutInflater.inflate(R.layout.rowofcells, null) as LinearLayout
            for (col in 0..number-1) {
                var tx_cell: TextView?
                if (row % 2 == col %2) {
                    tx_cell = layoutInflater.inflate(R.layout.redcell, null) as TextView
                } else {
                    tx_cell = layoutInflater.inflate(R.layout.bluecell, null) as TextView
                }
                lt_row.addView(tx_cell)
            }
            lt_board.addView(lt_row)
        }
    }
}