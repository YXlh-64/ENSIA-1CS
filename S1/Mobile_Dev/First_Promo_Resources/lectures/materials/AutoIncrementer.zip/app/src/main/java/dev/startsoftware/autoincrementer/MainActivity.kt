package dev.startsoftware.autoincrementer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    var increment=0
    var is_running=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var bt_start=findViewById<Button>(R.id.bt_start)
        bt_start.setOnClickListener {
            if (!is_running) {
                startCounting()
                bt_start.setText("Stop Running")
                is_running=true
            }else{
                bt_start.setText("Start")
                is_running=false
            }
        }
    }
    private fun startCounting(){
        var tx_counter=findViewById<TextView>(R.id.tx_counter)
        var handler = Handler(Looper.getMainLooper())
        val runnable =object : Runnable{
            override fun run() {
                    if (!is_running) return
                    increment = increment + 1
                    tx_counter.setText("" + increment)
                    println("running the thread.......")
                handler.postDelayed(this, 1000)
            }
        }
        handler.postDelayed(runnable, 1000)
    }
}