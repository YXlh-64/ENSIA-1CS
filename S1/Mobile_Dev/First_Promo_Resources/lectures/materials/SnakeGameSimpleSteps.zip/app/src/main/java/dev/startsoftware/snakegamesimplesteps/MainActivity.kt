package dev.startsoftware.snakegamesimplesteps

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.w3c.dom.Text
import java.util.Vector

class MainActivity : AppCompatActivity() {
    var boardSize=40
    var board_data= arrayOfNulls<Array<TextView?>>(boardSize)
    var direction="right"
    var is_running=false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        buildGrid(boardSize)
        initSnake()
        generateFood()

        var bt_start=findViewById<Button>(R.id.bt_start)
        bt_start.setOnClickListener {
            if (!is_running) {
                createThreadMoveSnake()
                bt_start.setText("Pause the Game")
                is_running=true
            }else{
                bt_start.setText("Start")
                is_running=false
            }
        }


        var bt_right=findViewById<Button>(R.id.bt_right)
        bt_right.setOnClickListener {
            direction="right"
        }

        var bt_down=findViewById<Button>(R.id.bt_down)
        bt_down.setOnClickListener {
            direction="down"
        }
        var bt_up=findViewById<Button>(R.id.bt_up)
        bt_up.setOnClickListener {
            direction="up"
        }
        var bt_left=findViewById<Button>(R.id.bt_left)
        bt_left.setOnClickListener {
            direction="left"
        }
    }
    var food_row:Int=0
    var food_col:Int=0

    private fun generateFood(){
        food_row=(0..boardSize-1).random()
        food_col=(0..boardSize-1).random()

        var cell= board_data[food_row]?.get(food_col) as TextView
        cell.setBackgroundColor(Color.parseColor("#0000ff"))
    }
    var snakeCells= Vector<String>()

    private fun initSnake(){
        snakeCells.removeAllElements()
        snakeCells.add("10x10")
        snakeCells.add("10x11")
        snakeCells.add("10x12")

        var cell= board_data[10]?.get(10) as TextView
        cell.setBackgroundColor(Color.parseColor("#ff0000"))

        cell= board_data[10]?.get(11) as TextView
        cell.setBackgroundColor(Color.parseColor("#ff0000"))

        cell= board_data[10]?.get(12) as TextView
        cell.setBackgroundColor(Color.parseColor("#ff0000"))
    }
    private fun createThreadMoveSnake(){
        var handler = Handler(Looper.getMainLooper())
        val runnable =object : Runnable{
            override fun run() {
                if (!is_running) return
                moveSnake()
                handler.postDelayed(this, 300)
            }
        }
        handler.postDelayed(runnable, 300)
    }
    fun moveSnake(){
        var headVals=snakeCells.get(snakeCells.size-1).split("x")
        var tailVals=snakeCells.get(0).split("x")
        var head_row=headVals[0].toString().toInt()
        var head_col=headVals[1].toString().toInt()
        var tail_row=tailVals[0].toString().toInt()
        var tail_col=tailVals[1].toString().toInt()

        println("Direction is "+direction)
        if (direction=="right") {
            head_col = head_col + 1
        }
        if (direction=="left") {
            head_col = head_col - 1
        }
        if (direction=="down") {
            head_row = head_row + 1
        }
        if (direction=="up") {
            head_row = head_row - 1
        }
        if ( head_col<0 || tail_col <0 || head_row <0 || tail_row<0 ||
                head_col>=boardSize || tail_col>=boardSize || head_row>=boardSize || tail_row>=boardSize)
            return

        snakeCells.add(""+head_row+"x"+head_col)
        snakeCells.removeElementAt(0)

        var cell= board_data[head_row]?.get(head_col) as TextView
        cell.setBackgroundColor(Color.parseColor("#ff0000"))
        println("new head > "+head_row+"x"+head_col+" :  "+cell)
        restoreCellOfGrid(tail_row,tail_col)
    }
    private fun restoreCellOfGrid(row:Int,col:Int){
        var cell= board_data[row]?.get(col) as TextView
        if (row % 2 == col %2) {
            cell.setBackgroundColor(Color.parseColor("#ECE5B6"))
        } else {
            cell.setBackgroundColor(Color.parseColor("#E0FFFF"))
        }
    }
    private fun buildGrid(number: Int){
        var lt_board=findViewById<LinearLayout>(R.id.lt_board)
        lt_board.removeAllViews()
        for (row in 0..number-1) {
            var lt_row = layoutInflater.inflate(R.layout.rowofcells, null) as LinearLayout
            var row_data= arrayOfNulls<TextView>(number)
            for (col in 0..number-1) {
                var tx_cell: TextView?
                if (row % 2 == col %2) {
                    tx_cell = layoutInflater.inflate(R.layout.cellone, null) as TextView
                } else {
                    tx_cell = layoutInflater.inflate(R.layout.celltwo, null) as TextView
                }
                lt_row.addView(tx_cell)
                row_data[col]=tx_cell
            }
            lt_board.addView(lt_row)
            board_data[row]= row_data
        }
    }

}