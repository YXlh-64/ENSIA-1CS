package dev.startsoftware.simpleexpenseappnodb

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.util.Vector

class ListExpenseAdapter(context: Context, items: Vector<Expense>) : BaseAdapter() {
    private val context: Context
    private val items: Vector<Expense>

    override fun getCount(): Int {
        return items.size //returns total of items in the list
    }

    override fun getItem(position: Int): Any {
        return items[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent:ViewGroup?):
            View? {
        var convertView: View? = convertView
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                .inflate(R.layout.expenserow, parent, false)
        }
        val currentItem = getItem(position) as Expense
        val tx_name = convertView
            ?.findViewById(R.id.tx_name) as TextView
        val tx_date = convertView
            ?.findViewById(R.id.tx_date) as TextView
        val tx_price = convertView
            ?.findViewById(R.id.tx_price) as TextView

        tx_name.text=currentItem.name
        tx_date.text=currentItem.date
        tx_price.text=""+currentItem.price

        return convertView
    }
    init {
        this.context = context
        this.items = items
    }
}