package dev.startsoftware.simpleexpenseappnodb

class Expense(var name:String,var date:String,var price:Double)