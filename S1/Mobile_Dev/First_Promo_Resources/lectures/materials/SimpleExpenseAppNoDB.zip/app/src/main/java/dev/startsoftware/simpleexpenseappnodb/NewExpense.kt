package dev.startsoftware.simpleexpenseappnodb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class NewExpense : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_expense)
        var bt_cancel=findViewById<Button>(R.id.bt_cancel)
        bt_cancel.setOnClickListener {
            this.finish()
        }
        var bt_add=findViewById<Button>(R.id.bt_add)
        bt_add.setOnClickListener {
            var nameVal=findViewById<EditText>(R.id.tx_description).text.toString()
            var dateVal=findViewById<EditText>(R.id.tx_date).text.toString()
            var priceVal=findViewById<EditText>(R.id.tx_amout).text.toString().toDouble()
            MainActivity.data.add(Expense(nameVal,dateVal,priceVal))

            val intent = Intent()
            intent.putExtra("some_var_back", "AnyValueYouWant")
            this.setResult(RESULT_OK, intent)
            this.finish()
        }
    }
}