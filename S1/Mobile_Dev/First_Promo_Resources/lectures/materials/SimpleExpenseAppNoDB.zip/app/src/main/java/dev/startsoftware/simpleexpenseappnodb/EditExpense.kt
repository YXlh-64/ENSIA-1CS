package dev.startsoftware.simpleexpenseappnodb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class EditExpense : AppCompatActivity() {
    var expense : Expense?=null
    var position_id=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_expense)
        val extras = intent.extras
        if (extras != null) {
            position_id = extras.getInt("position_id")
            expense=MainActivity.data.get(position_id) as Expense
            var tx_name=findViewById<EditText>(R.id.tx_description)
            var tx_date=findViewById<EditText>(R.id.tx_date)
            var tx_price=findViewById<EditText>(R.id.tx_amount)
            tx_name.setText(expense!!.name)
            tx_date.setText(expense!!.date)
            tx_price.setText(""+expense!!.price)
        }
        var bt_save=findViewById<Button>(R.id.bt_save)
        bt_save.setOnClickListener {
            expense?.name=findViewById<EditText>(R.id.tx_description).text.toString()
            expense?.date=findViewById<EditText>(R.id.tx_date).text.toString()
            expense?.price=findViewById<EditText>(R.id.tx_amount).text.toString().toDouble()
            //MainActivity.data.set(position_id,expense)
            val intent = Intent()
            this.setResult(RESULT_OK, intent)
            this.finish()
        }

    }
}