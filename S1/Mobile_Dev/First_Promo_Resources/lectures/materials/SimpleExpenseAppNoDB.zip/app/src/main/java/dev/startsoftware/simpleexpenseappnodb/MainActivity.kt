package dev.startsoftware.simpleexpenseappnodb

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Vector


class MainActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        println("on Resuming....")
        printExpenses()
    }
    private fun printExpenses(){
        println(">>>>>Printing Expenses"+data.size)
        for (item in data){
            println(">>>>>"+item.name)
        }
    }
    companion object {
        var data = Vector<Expense>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var bt_new=findViewById<Button>(R.id.bt_new)
        bt_new.setOnClickListener {
            val intent = Intent(this, NewExpense::class.java)
            intent.putExtra("some_variable", "HelloWorld !")
            intent.putExtra("another_variable", 12)
            launchActivityNewExpense.launch(intent)
        }

        var lv_expenses=findViewById<ListView>(R.id.lv_expenses)
        lv_expenses.setOnItemClickListener { parent, view, position, id ->
            println("Item Clicked at Position "+position+" with ID : "+id+" "+data.get(position).name)
            val intent = Intent(this, EditExpense::class.java)
            intent.putExtra("expense_index", position)
            launchActivityNewExpense.launch(intent)
        }
    }

    var launchActivityNewExpense = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { result ->
        println("Get data back<<<<<<Result Code : "+ result.resultCode)
        if (result.resultCode == Activity.RESULT_OK) {
            println("Get data back<<<<<<")
            printExpenses()
            drawExpense()
        }
    }
    private fun drawExpense(){
        var lv_expenses=findViewById<ListView>(R.id.lv_expenses)
        lv_expenses.adapter=ListExpenseAdapter(this,data)
        lv_expenses.refreshDrawableState()
    }

}